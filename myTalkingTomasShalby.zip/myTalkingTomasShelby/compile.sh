g++ -c main.cpp -I/home/kega/Documents/prog/libs/SFML-3.0.0/include
g++ main.o -o sfml-app -L /home/kega/Documents/prog/libs/SFML-3.0.0/lib -lsfml-graphics -lsfml-window -lsfml-system
./sfml-app
rm sfml-app
rm main.o
