#pragma once

#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics.h>
#include "../UI/Button.h"
#include <SFML/Graphics/Sprite.hpp>
#include <vector>
class Scene{
    private:
        std::vector<Button> buttons;
        std::vector<sf::Sprite> sprites;
        int mainFunc;
        bool activity = 0;
    public:
        int buttonCount = 0;
        void addButton(Button button){
            buttons.push_back(button);
            button.setTag(buttonCount++);
        }
        void addSprite(sf::Sprite sprite){
            sprites.push_back(sprite);
        }
        void draw(sf::RenderWindow& window) {
            for (Button &button : buttons) {
                button.draw(window);
            }
            for (auto &sprite : sprites) {
                window.draw(sprite);
            }
        }
        int getButtonsQuantity(){
            return buttons.size();
        }
        int getSpritesQuantity(){
            return buttons.size();
        }
        Button getButton(int index){
            return buttons[index];
        }
        sf::Sprite getSprite(int index){
            return sprites[index];
        }
        std::vector<Button> getButtons(){
            return buttons;
        }
        std::vector<sf::Sprite> getSprites(){
            return sprites;
        }
        void setActive(bool active){
            activity = active;
        }
        bool isActive(){
            return activity;
        }
};
