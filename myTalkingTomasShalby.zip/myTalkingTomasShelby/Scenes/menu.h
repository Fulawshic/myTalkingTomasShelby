#pragma once

#include <SFML/Graphics.h>
#include <SFML/System/Vector2.hpp>
#include <SFML/Window.hpp>
#include <cstddef>
#include "../UI/Button.h"
#include "Scene.h"
class mainmenu:public Scene{
    private:
        sf::RenderWindow window;
        sf::Event event;
        Button upButton;
        Button downButton;
        Button useButton;
        std::string fontPath = "../Fonts/arial.ttf";
        unsigned int windowHeight = 600;
        unsigned int windowWidth = 400;
    public:
    void build(){
        Button nothing;
        buttonCount = 0;
        int upButtonHeight = windowHeight/8;
        int upButtonWidth =  windowWidth/2;
        upButton.setPosition(0, windowHeight-upButtonHeight*2, upButtonWidth, upButtonHeight);
            upButton.setColor(sf::Color::White);
            upButton.setOutline(-1, sf::Color::Black);
            upButton.setTitle(fontPath, "up", 10, sf::Color::Black);
            //upButton.setTag(buttonNumber++);
            addButton(upButton);

        int downButtonHeight = windowHeight/8;
        int downButtonWidth =  windowWidth/2;
        downButton.setPosition(0, windowHeight-downButtonHeight, downButtonWidth, downButtonHeight);
            downButton.setTitle(fontPath, "down", 24, sf::Color::Black);
            downButton.setColor(sf::Color::White);
            downButton.setOutline(-1, sf::Color::Black);
            //downButton.setTag(buttonNumber++);
            addButton(downButton);

        int useButtonHeight = windowHeight/4;
        int useButtonWidth =  windowWidth/2;
        useButton.setPosition(windowWidth-upButtonWidth, windowHeight-useButtonHeight, useButtonWidth, useButtonHeight);
            useButton.setColor(sf::Color::White);
            useButton.setOutline(-1, sf::Color::Black);
            useButton.setTitle(fontPath, "use", 24, sf::Color::Black);
            //useButton.setTag(buttonNumber++);
            addButton(useButton);
        printf("\nwindowHeight = %i windowWidth = %i\n\n", windowHeight, windowWidth);
    }
    void load(){
        window.create(sf::VideoMode({windowWidth,windowHeight}),"test");
        while(window.isOpen()){
            while(window.pollEvent(event)){
                if(event.type == sf::Event::Closed){
                    window.close();
                }
                if(event.type == sf::Event::Resized){
                    sf::Vector2f windowSize;
                    windowWidth = windowSize.x;
                    windowHeight = windowSize.y;
                    build();
                }
            }
            window.clear();
            for (int i = 0; i<=2;++i) {
                getButton(i).draw(window);
            }
            window.display();
        }
    }
};
