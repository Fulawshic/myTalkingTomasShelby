#pragma once
#include <SFML/Graphics.h>
#include <vector>

class Option{
    private:
        std::vector <Option> options;
        int optionsPosX;
        int opsionsPosY;
        int optionsWidth;
        int optionsHeigth;
        int tag;
    public:
        void setHitboxPos(int posX, int posY, int width, int heigth){
            optionsPosX = posX;
            opsionsPosY = posY;
            optionsWidth = width;
            optionsHeigth = heigth;
        }
        void setTag(int Tag){
            tag = Tag;
        }
};
