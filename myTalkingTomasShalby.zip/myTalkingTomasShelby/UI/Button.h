#pragma once

#include <SFML/Graphics/Color.hpp>
#include <SFML/Graphics/Font.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/System/Vector2.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <stdio.h>
#include <string>
using namespace std;

class Button{
    private:
        //data
        sf::Text text;
        sf::Font font;
        sf::RectangleShape hitbox;
        sf::Color buttonColor;
        sf::Color titleColor;
        sf::Texture texture;
        sf::Color outlineColor;
        string Title;
        unsigned int hitboxPosX;
        unsigned int hitboxPosY;
        float hitboxWidth;
        float hitboxHeight;
        bool mouseInHitbox;
        unsigned int buttonTag;
    public:
    void setPosition(
        unsigned int X,
        unsigned int Y,
        float Width,
        float Heigth){
        hitboxPosX = X;
        hitboxPosY = Y;
        hitboxWidth = Width;
        hitboxHeight = Heigth;
        hitbox.setPosition(hitboxPosX, hitboxPosY);
        hitbox.setSize({hitboxWidth,hitboxHeight});
        /*
        printf("HBpX=%i\n",hitboxPosX);
        printf("HBpY=%i\n",hitboxPosY);("UI/Fonts/arial.ttf");
        printf("HBW=%i\n",hitboxWidth);
        printf("HBH=%i\n",hitboxHeight);
        */
    }
    void setColor(sf::Color color = sf::Color::White){
        buttonColor = color;
        hitbox.setFillColor(buttonColor);
    }
    void setOutline(int outline = 0, sf::Color lineColor = sf::Color::Transparent){
        outlineColor = lineColor;
        hitbox.setOutlineThickness(outline);
        hitbox.setOutlineColor(outlineColor);
    }
    void setTag(int tag){
        const unsigned int buttonTag = tag;
        printf("tag=%i\n",buttonTag);
    }
    int getTag(){
        return buttonTag;
    }

    void setTitle(string fontPath, string title, int fontSize, sf::Color color) {
            Title = title;
            titleColor = color;
            if (!font.loadFromFile(fontPath)) {
                printf("Error: Failed to load font from ");
            }
            text.setFont(font);
            text.setString(Title);
            text.setCharacterSize(fontSize);
            text.setPosition(hitboxPosX, hitboxPosY);
            text.setFillColor(titleColor);
        }
bool isPressed(sf::RenderWindow& window){
    sf::Vector2 mousePos = sf::Mouse::getPosition(window);
    bool isLMB = sf::Mouse::isButtonPressed(sf::Mouse::Left);
    bool isRMB = sf::Mouse::isButtonPressed(sf::Mouse::Right);
    if(mousePos.x >= hitboxPosX &&
        mousePos.x <= hitboxPosX + hitboxWidth &&
        mousePos.y >= hitboxPosY &&
        mousePos.y <= hitboxPosY + hitboxHeight
        ){
        //printf("mouseInHitbox = %b\n", mouseInHitbox);
        mouseInHitbox = 1;
    }else{
        //printf("mouseInHitbox = %b\n", mouseInHitbox);
        mouseInHitbox = 0;
    }

    if(sf::Mouse::isButtonPressed(sf::Mouse::Left) && mouseInHitbox){
        printf("isPressed");
        return 1;
    }
    else {
        return 0;
    }
}
void draw(sf::RenderWindow& window){
            window.draw(hitbox);
            window.draw(text);
        }
};
