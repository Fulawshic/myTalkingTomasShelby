#include "Scenes/menu.h"
int main(){
    mainmenu menu;
    menu.build();
    menu.load();
}
